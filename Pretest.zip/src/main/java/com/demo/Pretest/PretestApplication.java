package com.demo.Pretest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PretestApplication {

	public static void main(String[] args) {
		SpringApplication.run(PretestApplication.class, args);
	}

}
